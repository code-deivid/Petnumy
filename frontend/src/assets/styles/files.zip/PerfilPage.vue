<!-- src/pages/PerfilPage.vue -->
<!-- Página de perfil básica — ampliable en el futuro -->
<script setup>
import { ref, computed } from 'vue'
import { useI18n }       from 'vue-i18n'
import { useRouter }     from 'vue-router'
import { useApi }        from '@/composables/useApi.js'
import { useAuthStore }  from '@/stores/auth.store.js'

const { t }     = useI18n()
const router    = useRouter()
const { patch } = useApi()
const authStore = useAuthStore()

const guardando = ref(false)
const mensaje   = ref(null)
const error     = ref(null)

const form = ref({
  nombre:    authStore.usuario?.nombre    || '',
  apellidos: authStore.usuario?.apellidos || ''
})

const iniciales = computed(() => {
  const n = form.value.nombre    || ''
  const a = form.value.apellidos || ''
  return ((n[0] || '') + (a[0] || '')).toUpperCase() || 'U'
})

async function guardar() {
  guardando.value = true
  mensaje.value   = null
  error.value     = null

  const { ok, data } = await patch('/api/auth/me', {
    nombre:    form.value.nombre.trim(),
    apellidos: form.value.apellidos.trim() || undefined
  })

  guardando.value = false

  if (!ok) { error.value = data.message || t('common.error'); return }

  authStore.setUsuario(data.usuario)
  mensaje.value = '¡Perfil actualizado correctamente!'
}
</script>

<template>
  <div class="page-container page-section">

    <div class="perfil-head">
      <button class="btn btn-ghost btn-sm back-btn" @click="router.back()">← {{ t('common.back') }}</button>
      <h1>{{ t('settings.profile') }}</h1>
    </div>

    <div class="perfil-layout">

      <!-- Columna avatar -->
      <div class="perfil-avatar-col">
        <div class="perfil-avatar">{{ iniciales }}</div>
        <p class="perfil-nombre">{{ form.nombre }} {{ form.apellidos }}</p>
        <p class="perfil-email">{{ authStore.usuario?.email }}</p>
      </div>

      <!-- Columna formulario -->
      <div class="card perfil-card">
        <div class="card-body">
          <h2 style="margin-bottom:1.25rem; font-size:1.1rem">Información personal</h2>

          <Transition name="fade">
            <div v-if="mensaje" class="msg msg-success" style="margin-bottom:1rem">{{ mensaje }}</div>
          </Transition>
          <Transition name="fade">
            <div v-if="error" class="msg msg-error" style="margin-bottom:1rem">{{ error }}</div>
          </Transition>

          <div class="perfil-form">
            <div class="form-row">
              <div class="input-group">
                <label class="label">{{ t('auth.name') }}</label>
                <input v-model="form.nombre" type="text" class="input" placeholder="María" />
              </div>
              <div class="input-group">
                <label class="label">{{ t('auth.lastName') }}</label>
                <input v-model="form.apellidos" type="text" class="input" placeholder="García" />
              </div>
            </div>

            <div class="input-group">
              <label class="label">{{ t('auth.email') }}</label>
              <input :value="authStore.usuario?.email" type="email" class="input" disabled style="opacity:.55;cursor:not-allowed" />
            </div>

            <div class="perfil-actions">
              <button class="btn btn-teal" :disabled="guardando" @click="guardar">
                <span v-if="guardando" class="spinner" style="width:15px;height:15px;border-width:2px"/>
                <span v-else>{{ t('common.save') }}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>

<style scoped>
.perfil-head { display: flex; flex-direction: column; gap: 0.4rem; margin-bottom: 2rem; }
.back-btn { align-self: flex-start; padding-left: 0; color: var(--color-text-muted); }

.perfil-layout {
  display: grid;
  grid-template-columns: 220px 1fr;
  gap: 2rem;
  align-items: start;
}

.perfil-avatar-col {
  display: flex; flex-direction: column; align-items: center;
  gap: 0.5rem; text-align: center;
}

.perfil-avatar {
  width: 88px; height: 88px; border-radius: 50%;
  background: var(--color-primary-light);
  border: 3px solid var(--color-primary);
  display: flex; align-items: center; justify-content: center;
  font-family: var(--font-display); font-weight: 800; font-size: 1.75rem;
  color: var(--color-primary-dark);
}

.perfil-nombre { font-family: var(--font-display); font-weight: 700; font-size: 1rem; color: var(--color-text); margin: 0; }
.perfil-email  { font-size: 0.8rem; color: var(--color-text-muted); margin: 0; }

.perfil-card { box-shadow: var(--shadow-md); }

.perfil-form { display: flex; flex-direction: column; gap: 1rem; }

.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 0.75rem; }

.perfil-actions { display: flex; justify-content: flex-end; padding-top: 0.5rem; }

@media (max-width: 640px) {
  .perfil-layout { grid-template-columns: 1fr; }
  .form-row { grid-template-columns: 1fr; }
}
</style>
